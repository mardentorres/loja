import Main from './screens/Main';

export default Main;
