import Cart from './screens/Cart';

export default Cart;
