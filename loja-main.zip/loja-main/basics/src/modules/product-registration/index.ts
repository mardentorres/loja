import ProductRegistration from './screens/ProductRegistration';

export default ProductRegistration;
