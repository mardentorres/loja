import Shop from './screens/Shop';

export default Shop;
