import Home from './screens/Home';

export default Home;
