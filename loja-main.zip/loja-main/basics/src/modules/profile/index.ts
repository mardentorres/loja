import Profile from './screens/Profile';

export default Profile;
