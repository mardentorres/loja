export const AUTORIZATION_KEY = '@vendas_AUTORIZATION_KEY';
export const API_ADDRESS = '@vendas_API_ADDRESS';
